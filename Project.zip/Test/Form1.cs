﻿using PicoFile_Direct_Link;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using MaterialSkin.Animations;
using MaterialSkin;
namespace Test
{
    public partial class Form1 : MaterialForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PicoFile pf = new PicoFile(txt_url.Text);
            if (chk_pass.Checked)
                txt_result.Text = pf.DirectLink(txt_pass.Text);
            else
                txt_result.Text = pf.DirectLink();
        }

        private void chk_pass_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_pass.Checked)
                txt_pass.Enabled = true;
            else
                txt_pass.Enabled = false;
        }
    }
}
